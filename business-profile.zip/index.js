const express = require("express");
const path = require("path");
const crypto = require("crypto");
const QRCode = require("qrcode");

const app = express();
const PORT = Number(process.env.PORT) || 3000;

const profiles = [];

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/data/profiles", (req, res) => {
  const { name, phone, address, logoUrl } = req.body || {};

  if (!name || !phone || !address) {
    return res
      .status(400)
      .json({ error: "Name, phone, and address are required." });
  }

  const id = crypto.randomBytes(6).toString("hex");
  const profile = {
    id,
    name: String(name).trim(),
    phone: String(phone).trim(),
    address: String(address).trim(),
    logoUrl: logoUrl ? String(logoUrl).trim() : "",
    createdAt: new Date().toISOString(),
  };
  profiles.push(profile);

  res.status(201).json({ id, link: `/profile.html?id=${id}` });
});

app.get("/data/profiles/:id", async (req, res) => {
  const profile = profiles.find((p) => p.id === req.params.id);
  if (!profile) {
    return res.status(404).json({ error: "Profile not found." });
  }

  const host = req.get("host");
  const protocol = req.get("x-forwarded-proto") || req.protocol;
  const profileUrl = `${protocol}://${host}/profile.html?id=${profile.id}`;

  try {
    const qrDataUrl = await QRCode.toDataURL(profileUrl, {
      width: 320,
      margin: 1,
      color: { dark: "#0f172a", light: "#ffffff" },
    });
    res.json({ ...profile, profileUrl, qrDataUrl });
  } catch (err) {
    res.status(500).json({ error: "Failed to generate QR code." });
  }
});

app.get("/data/profiles", (_req, res) => {
  res.json(
    profiles.map((p) => ({
      id: p.id,
      name: p.name,
      link: `/profile.html?id=${p.id}`,
    })),
  );
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Business Profile server listening on port ${PORT}`);
});
